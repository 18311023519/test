<?php
/*
 * @author xuruiqi
 * @date   20150406
 * @copyright reetsee.com
 */     
class Phpfetcher_Manager_Abstract {

}
?>
